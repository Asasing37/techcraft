
USE agencia_viajes;

-- Clientes
INSERT INTO clientes (nombre, correo, telefono, fecha_registro) VALUES 
('Juan Perez', 'juan@example.com', '3001112233', NOW()),
('Maria Gomez', 'maria@example.com', '3004445566', NOW()),
('Carlos Diaz', 'carlos@example.com', '3012223344', NOW()),
('Laura Martinez', 'laura@example.com', '3025556677', NOW());

-- Hoteles
INSERT INTO hoteles (nombre, ubicacion, estrellas, descripcion) VALUES 
('Hotel Sol', 'Cartagena', 5, 'Frente al mar'),
('Hotel Luna', 'Bogotá', 4, 'Centro de negocios'),
('Hotel Estrella', 'Medellín', 3, 'Económico y bien ubicado');

-- Habitaciones
INSERT INTO habitaciones (hotel_id, tipo, precio, disponibilidad) VALUES 
(1, 'Suite', 300.00, TRUE),
(1, 'Doble', 150.00, TRUE),
(2, 'Individual', 100.00, TRUE),
(3, 'Doble', 120.00, TRUE);

-- Aerolíneas
INSERT INTO aerolineas (nombre) VALUES 
('Avianca'),
('LATAM'),
('Viva Air');

-- Vuelos
INSERT INTO vuelos (aerolinea_id, origen, destino, fecha, asientos_disponibles) VALUES 
(1, 'Bogotá', 'Cartagena', '2025-05-01 10:00:00', 100),
(2, 'Medellín', 'Santa Marta', '2025-05-02 08:00:00', 80),
(3, 'Bogotá', 'Medellín', '2025-05-03 12:30:00', 60);

-- Paquetes
INSERT INTO paquetes (nombre, descripcion, precio, hotel_id, vuelo_id) VALUES 
('Paquete Caribe', 'Todo incluido a Cartagena', 1200.00, 1, 1),
('Paquete Montaña', 'Descubre Medellín', 950.00, 3, 3),
('Paquete Relax', 'Santa Marta para 2', 1100.00, 2, 2);

-- Reservas
INSERT INTO reservas (cliente_id, paquete_id, fecha_reserva, estado, total) VALUES 
(1, 1, NOW(), 'confirmada', 1200.00),
(2, 2, NOW(), 'confirmada', 950.00),
(3, 3, NOW(), 'pendiente', 1100.00);

-- Promociones
INSERT INTO promociones (nombre, descuento, paquete_id, fecha_inicio, fecha_fin) VALUES 
('Promo Verano', 20.00, 1, '2025-04-01', '2025-06-30'),
('Oferta Especial', 15.00, 2, '2025-04-10', '2025-05-10');

-- Proveedores
INSERT INTO proveedores (nombre, tipo, api_key) VALUES 
('Hotel Sol', 'Hotel', 'abc123'),
('LATAM', 'Aerolínea', 'def456');

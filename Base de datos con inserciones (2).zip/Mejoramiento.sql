CREATE DATABASE agencia_viajes;
USE agencia_viajes;

-- Tabla de Clientes
CREATE TABLE clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    correo VARCHAR(100) UNIQUE,
    telefono VARCHAR(20),
    fecha_registro DATE
);

-- Tabla de Hoteles
CREATE TABLE hoteles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    ubicacion VARCHAR(100),
    estrellas INT,
    descripcion TEXT
);

-- Tabla de Habitaciones
CREATE TABLE habitaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hotel_id INT,
    tipo VARCHAR(50),
    precio DECIMAL(10, 2),
    disponibilidad BOOLEAN,
    FOREIGN KEY (hotel_id) REFERENCES hoteles(id)
);

-- Tabla de Aerolíneas
CREATE TABLE aerolineas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100)
);

-- Tabla de Vuelos
CREATE TABLE vuelos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    aerolinea_id INT,
    origen VARCHAR(100),
    destino VARCHAR(100),
    fecha DATETIME,
    asientos_disponibles INT,
    FOREIGN KEY (aerolinea_id) REFERENCES aerolineas(id)
);

-- Tabla de Paquetes
CREATE TABLE paquetes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    descripcion TEXT,
    precio DECIMAL(10,2),
    hotel_id INT,
    vuelo_id INT,
    FOREIGN KEY (hotel_id) REFERENCES hoteles(id),
    FOREIGN KEY (vuelo_id) REFERENCES vuelos(id)
);

-- Tabla de Reservas
CREATE TABLE reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT,
    paquete_id INT,
    fecha_reserva DATE,
    estado VARCHAR(50),
    total DECIMAL(10,2),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (paquete_id) REFERENCES paquetes(id)
);

-- Tabla de Proveedores (Hoteles o Aerolíneas)
CREATE TABLE proveedores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    tipo ENUM('Hotel', 'Aerolínea'),
    api_key VARCHAR(100)
);

-- Tabla de Promociones
CREATE TABLE promociones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    descuento DECIMAL(5,2), -- porcentaje
    paquete_id INT,
    fecha_inicio DATE,
    fecha_fin DATE,
    FOREIGN KEY (paquete_id) REFERENCES paquetes(id)
);

-- Tabla de Usuarios (clientes, agentes, proveedores)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    rol ENUM('cliente', 'agente', 'proveedor')
);